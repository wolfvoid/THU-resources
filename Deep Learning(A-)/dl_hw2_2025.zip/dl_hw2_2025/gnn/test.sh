#!/bin/bash
export CUDA_VISIBLE_DEVICES=6
python segmentation.py test \
--dataset fusiongallery \
--dataset_path ./brep_data \
--desc " " \
--accelerator gpu \
--devices 1 \
--checkpoint $YOUR_EXPERIMENT_PATH/best.ckpt
