import torch
import torch.nn as nn


class Baseline(nn.Module):
    def __init__(self, height, width, num_targets):
        super(Baseline, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(1, 32, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self._feature_size = self._get_feature_size(height, width)
        self.regressor = nn.Sequential(
            nn.Linear(self._feature_size, 256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, 64),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(64, num_targets)
        )

    def _get_feature_size(self, height, width):
        dummy_input = torch.zeros(1, 1, height, width)
        with torch.no_grad():
            features = self.conv(dummy_input)
        return features.view(1, -1).shape[1]

    def forward(self, x):
        features = self.conv(x)
        features = features.view(features.size(0), -1)
        output = self.regressor(features)
        means = output[:, :2]
        log_sigmas = output[:, 2:]
        sigmas = torch.exp(log_sigmas)
        return means, sigmas


# TODO : Define your model here

