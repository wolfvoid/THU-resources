import argparse
import os
import random
import time

import numpy as np
import torch
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import DataLoader
from torchvision import transforms
from tqdm import tqdm

from model import Baseline
from utils import Score, CosmologyDataset


class Config:
    def __init__(self, data_shape):
        self.IMG_HEIGHT = data_shape[0]
        self.IMG_WIDTH = data_shape[1]
        self.NUM_TARGETS = 4

        self.BATCH_SIZE = 16
        self.EPOCHS = 10
        self.LEARNING_RATE = 2e-4
        self.WEIGHT_DECAY = 1e-4
        self.DEVICE = "cuda" if torch.cuda.is_available() else "cpu"




def KL_div_posterior_loss(pred_means, pred_sigmas, truths):
    residuals_sq = (pred_means - truths) ** 2
    loss_terms = residuals_sq / (pred_sigmas ** 2)
    loss_sum = torch.sum(loss_terms, dim=1)
    log_sigma_terms = torch.sum(torch.log(pred_sigmas ** 2), dim=1)
    loss = torch.mean(loss_sum + log_sigma_terms)
    return loss


def train_epoch(model, dataloader, loss_fn, optimizer, device):
    model.train()
    total_loss = 0
    pbar = tqdm(dataloader, total=len(dataloader), desc="Training")
    for X, y in pbar:
        X, y = X.to(device), y.to(device)

        # Forward pass
        pred_means, pred_sigmas = model(X)
        loss = loss_fn(pred_means, pred_sigmas, y)

        # Backward pass and optimization
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    return total_loss / len(dataloader)



def validate_epoch(model, dataloader, loss_fn, device):
    model.eval()
    total_loss = 0
    pbar = tqdm(dataloader, total=len(dataloader), desc="Validating")
    with torch.no_grad():
        for X, y in pbar:
            X, y = X.to(device), y.to(device)
            pred_means, pred_sigmas = model(X)
            total_loss += loss_fn(pred_means, pred_sigmas, y).item()

    return total_loss / len(dataloader)


def main(args):
    fix_seed = 2025
    torch.manual_seed(fix_seed)
    random.seed(fix_seed)
    np.random.seed(fix_seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(fix_seed)
        torch.cuda.manual_seed_all(fix_seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    noisy_kappa = np.load(os.path.join(args.data_root, 'WIDE12H_bin2_2arcmin_kappa_noisy_downsampled_f3.npy'))
    label = np.load(os.path.join(args.data_root, 'label.npy'))
    print(f"Loaded downsampled data shape: {noisy_kappa.shape}")
    print(f"Loaded label shape: {label.shape}")

    Ncosmo, Nsys, H, W = noisy_kappa.shape
    shape = (H, W)

    # 数据分割 - 保持完全相同的参数
    NP_idx = np.arange(Nsys)
    split_fraction = 0.2

    train_NP_idx, val_NP_idx = train_test_split(NP_idx, test_size=split_fraction,
                                                random_state=fix_seed)

    noisy_kappa_train = noisy_kappa[:, train_NP_idx]
    label_train = label[:, train_NP_idx]
    noisy_kappa_val = noisy_kappa[:, val_NP_idx]
    label_val = label[:, val_NP_idx]

    Ntrain = label_train.shape[0] * label_train.shape[1]
    Nval = label_val.shape[0] * label_val.shape[1]

    print(f'Shape of the split training data = {noisy_kappa_train.shape}')
    print(f'Shape of the split validation data = {noisy_kappa_val.shape}')
    print(f'Shape of the split training labels = {label_train.shape}')
    print(f'Shape of the split validation labels = {label_val.shape}')


    # 数据重塑
    X_train = noisy_kappa_train.reshape(Ntrain, H, W)
    X_val = noisy_kappa_val.reshape(Nval, H, W)
    y_train = label_train.reshape(Ntrain, 5)[:, :2]
    y_val = label_val.reshape(Nval, 5)[:, :2]

    # 数据标准化 - 保持完全一致的处理流程
    means = np.mean(X_train, dtype=np.float32)
    stds = np.std(X_train, dtype=np.float32)

    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[means], std=[stds]),
    ])
    print(f"Image stats (from train set): Mean={means}, Std={stds}")

    label_scaler = StandardScaler()
    y_train_scaled = label_scaler.fit_transform(y_train)
    y_val_scaled = label_scaler.transform(y_val)
    print(f"Label stats (from train set): Mean={label_scaler.mean_}, Std={np.sqrt(label_scaler.var_)}")

    # 初始化配置
    config = Config(data_shape=shape)
    print(f"Using device: {config.DEVICE}")

    # 创建数据集和数据加载器
    train_dataset = CosmologyDataset(
        data=X_train,
        labels=y_train_scaled,
        transform=transform
    )
    val_dataset = CosmologyDataset(
        data=X_val,
        labels=y_val_scaled,
        transform=transform
    )

    train_loader = DataLoader(train_dataset, batch_size=config.BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=config.BATCH_SIZE, shuffle=False)

    # 初始化模型
    if args.model == 'Baseline':
        model = Baseline(config.IMG_HEIGHT,
                           config.IMG_WIDTH,
                           config.NUM_TARGETS).to(config.DEVICE)
    # TODO: Add other model options here
    else:
        raise ValueError(f"Model {args.model} is not supported.")

    # 打印模型参数量
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Model {args.model} initialized with {total_params} trainable parameters.")

    # 训练设置
    model_save_path = os.path.join(os.getcwd(), f"{args.model}_best_model.pth")
    loss_fn = KL_div_posterior_loss  # 注意：这里使用KL损失而不是MSE
    optimizer = torch.optim.Adam(model.parameters(),
                                 lr=config.LEARNING_RATE,
                                 weight_decay=config.WEIGHT_DECAY)
    scheduler = ReduceLROnPlateau(optimizer,
                                  mode='min',
                                  factor=0.5,
                                  patience=5)

    # 训练循环
    best_val_loss = float('inf')
    start_time = time.time()
    for epoch in range(config.EPOCHS):
        train_loss = train_epoch(model, train_loader, loss_fn, optimizer, config.DEVICE)
        val_loss = validate_epoch(model, val_loader, loss_fn, config.DEVICE)

        scheduler.step(val_loss)
        print(f"Epoch {epoch + 1}/{config.EPOCHS} | Train Loss: {train_loss:.6f} | Val Loss: {val_loss:.6f}")

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save(model.state_dict(), model_save_path)
            print(f"  -> New best model saved to {model_save_path}")

    end_time = time.time()
    print(f"\nTraining finished in {(end_time - start_time) / 60:.2f} minutes.")

    model.load_state_dict(torch.load(model_save_path, weights_only=True))

    # Validation
    print("Validating model...")
    model.eval()
    means_pred_list, sigmas_pred_list = [], []

    with torch.no_grad():
        for X, _ in tqdm(val_loader, desc="Validation inference"):
            X = X.to(config.DEVICE)
            means_pred, sigmas_pred = model(X)
            means_pred_list.append(means_pred.cpu().numpy())
            sigmas_pred_list.append(sigmas_pred.cpu().numpy())

    mean_val = np.concatenate(means_pred_list, axis=0)
    mean_val = label_scaler.inverse_transform(mean_val)

    errorbar_val = np.concatenate(sigmas_pred_list, axis=0)
    errorbar_val = errorbar_val * label_scaler.var_ ** 0.5

    # Apply non-negative prior
    negative_mask = mean_val - errorbar_val < 0
    errorbar_val[negative_mask] = mean_val[negative_mask]

    # Calculate scores
    validation_score = Score._score_phase1(y_val, mean_val, errorbar_val)
    print(f"\nValidation Score: {np.mean(validation_score):.6f}")
    print(f"Average Error Bar: {np.mean(errorbar_val, 0)}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='App Sequences Forecasting')
    parser.add_argument('--model', type=str, required=False, default='Baseline',
                        help='model of experiment')
    parser.add_argument('--data_root', type=str, required=False, default='./data',
                        help='data root path')
    args = parser.parse_args()
    main(args)