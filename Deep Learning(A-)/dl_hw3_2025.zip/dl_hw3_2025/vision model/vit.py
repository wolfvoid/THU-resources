import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

# --- 2D Rotary Positional Embedding (RoPE) Implementation ---

class RotaryEmbedding2D(nn.Module):
    """
    1.2 2D RoPE Implementation: Generates 2D rotation matrices based on patch indices.
    
    This implementation adapts the standard 1D RoPE for 2D images by treating the
    (x, y) coordinates of each patch as independent indices.
    """
    def __init__(self, dim, patch_size=8, image_size=64):
        super().__init__()
        self.dim = dim
        self.patch_size = patch_size
        
        # TODO
        
    def forward(self, t: torch.Tensor, seq_len: int):
        """
        Applies rotation to tensor t (Q or K).
        t: [B, H, N, D_head]
        """
        # TODO
        
        pass


class Attention(nn.Module):
    def __init__(self, dim, num_heads=12, dropout=0.0, rope_module=None):
        super().__init__()
        self.num_heads = num_heads
        self.scale = (dim // num_heads) ** -0.5
        self.qkv = nn.Linear(dim, dim * 3, bias=False)
        self.proj = nn.Linear(dim, dim)
        self.attn_drop = nn.Dropout(dropout)
        self.proj_drop = nn.Dropout(dropout)
        self.rope_module = rope_module

    def forward(self, x):
        B, N, C = x.shape

        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv.unbind(0)
        
        if self.rope_module is not None:
            
            # TODO
            # Note that q and k contain CLS token at index 0, so we need to separate it out
            # Then apply RoPE only to the patch tokens
            # Last concatenate the CLS token back
            pass

        attn = (q @ k.transpose(-2, -1)) * self.scale
        
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x


class Block(nn.Module):
    def __init__(self, dim, num_heads, mlp_ratio=4., dropout=0.0, rope_module=None):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = Attention(dim, num_heads=num_heads, dropout=dropout, rope_module=rope_module)
        self.norm2 = nn.LayerNorm(dim)
        
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Linear(dim, mlp_hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(mlp_hidden_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        x = x + self.attn(self.norm1(x)) 
        x = x + self.mlp(self.norm2(x)) 
        return x

class ViT(nn.Module):
    
    def __init__(self, image_size=64, patch_size=4, in_channels=3, num_classes=10, 
                 embed_dim=128, depth=4, num_heads=8, mlp_ratio=4., dropout=0.0):
        super().__init__()
        
        
        self.patch_embed = nn.Conv2d(in_channels, embed_dim, kernel_size=patch_size, stride=patch_size)
        
        num_patches = (image_size // patch_size) ** 2
        
        
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        
        self.pos_embed = None
        self.pos_drop = nn.Dropout(p=dropout)
        
        self.num_heads = num_heads
        
        self.rope_module = RotaryEmbedding2D(dim=embed_dim // num_heads, # RoPE operates on head dimension
                                             patch_size=patch_size, 
                                             image_size=image_size)

        self.blocks = nn.Sequential(*[
            Block(
                dim=embed_dim, 
                num_heads=num_heads, 
                mlp_ratio=mlp_ratio, 
                dropout=dropout,
                rope_module=self.rope_module
            )
            for i in range(depth)
        ])
        
        self.norm = nn.LayerNorm(embed_dim)

        self.head = nn.Linear(embed_dim, num_classes) if num_classes > 0 else nn.Identity()

    def forward_features(self, x):
        B = x.shape[0]
          
        x = self.patch_embed(x)

        x = x.flatten(2).transpose(1, 2) 

        cls_tokens = self.cls_token.expand(B, -1, -1)
        x = torch.cat((cls_tokens, x), dim=1)

        x = self.pos_drop(x)
        x = self.blocks(x)
        x = self.norm(x)

        return x[:, 0]

    def forward(self, x):
        x = self.forward_features(x)
        x = self.head(x)
        return x
