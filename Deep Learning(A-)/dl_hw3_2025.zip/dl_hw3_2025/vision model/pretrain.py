import torch
import torch.nn as nn
import torch.nn.functional as F
import vit
import mae
import os
import argparse
import  torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR

from tqdm import tqdm
import torchvision.transforms as transforms
import medmnist
from medmnist import INFO


def run_mae_pretrain(model, train_set, optimizer, scheduler, save_dir, batch_size=64, num_epochs=20):

    device = next(model.parameters()).device
    
    def train_mae(model, train_loader, optimizer):
        model.train(True)
        total_loss = 0.0
        
        # Note: MAE uses MSE, no labels needed.
        bar = tqdm(train_loader, desc='MAE Pre-train')
        for inputs, _ in bar: # Labels are ignored during pre-training
            inputs = inputs.to(device)
            optimizer.zero_grad()
            
            # Forward pass: returns loss, prediction, mask
            loss, _, _ = model(inputs)

            loss.backward()
            optimizer.step()

            total_loss += loss.item() * inputs.size(0)
            bar.set_postfix(mae_loss=loss.item())
        
        epoch_loss = total_loss / len(train_loader.dataset)
        return epoch_loss

    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
        
    loss_curve = []
    
    for epoch in range(num_epochs):
        print('MAE Pre-train epoch:{:d}/{:d}'.format(epoch, num_epochs))
        print('*' * 100)
        train_loader = torch.utils.data.DataLoader(train_set, batch_size=batch_size, shuffle=True, num_workers=10)
        
        train_loss = train_mae(model, train_loader, optimizer)
        scheduler.step()
        
        loss_curve.append(train_loss)
        print("MAE training loss: {:.4f}".format(train_loss))
    
    # Save the pre-trained encoder (ViT part) only
    torch.save(model.encoder.state_dict(), os.path.join(save_dir, 'mae_encoder_weights.pth'))
    
    print("\nMAE Pre-training complete. Reconstruction Loss Curve (for report):", loss_curve)
    return loss_curve


if __name__ == '__main__':
    
    parser = argparse.ArgumentParser(description='hw3')
    parser.add_argument('--save_dir', type=str, default='./checkpoints/', help='model save path')
    args = parser.parse_args()

    # data preparation
    data_flag = 'pathmnist'
    download = False
    info = INFO[data_flag]
    task = info['task']
    n_channels = info['n_channels']
    n_classes = len(info['label'])
    DataClass = getattr(medmnist, info['python_class'])

    data_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[.5], std=[.5])
    ])

    # download dataset first and modify the data_path accordingly
    data_path = './'
    train_dataset = DataClass(root=data_path, split='train', transform=data_transform, size=64, download=download)
    valid_dataset = DataClass(root=data_path, split='val', transform=data_transform, size=64, download=download)
    test_dataset = DataClass(root=data_path, split='test', transform=data_transform, size=64, download=download)
    
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


    # Initialize ViT encoder (without classification head)
    
    # you can modify the model size here if you want
    base_encoder = vit.ViT(num_classes=0, embed_dim=64, depth=2, num_heads=8) 
    
    # Initialize MAE model given the ViT encoder
    # The masking ratio is an important hyperparameter you can tune. Enjoy!
    mae_model = mae.MaskedAutoencoder(base_encoder, decoder_dim=64, decoder_depth=1, masking_ratio=0.75)
    mae_model = mae_model.to(device)

    mae_lr = 1e-3
    mae_epochs = 10
    batch_size = 64
    
    mae_optimizer = optim.AdamW(mae_model.parameters(), lr=mae_lr, betas=(0.9, 0.95), weight_decay=0.05)
    mae_scheduler = CosineAnnealingLR(mae_optimizer, T_max=mae_epochs)

    recons_loss_curve = run_mae_pretrain(mae_model, train_dataset, mae_optimizer, mae_scheduler, args.save_dir, batch_size=batch_size, num_epochs=mae_epochs)